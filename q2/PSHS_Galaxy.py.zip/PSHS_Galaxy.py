
class PSHS_Galaxy:
    def __init__(self, galaxy, planet):
        self.galaxy = galaxy          # public attribute
        self.__planet = planet        # private attribute

    def get_planet(self):
        return self.__planet


class Nationality(PSHS_Galaxy):
    def __init__(self, galaxy, planet, nationality, continent):
        super().__init__(galaxy, planet)
        self.nationality = nationality
        self.continent = continent


class Alien(PSHS_Galaxy):
    def __init__(self, galaxy, planet, name, species):
        super().__init__(galaxy, planet)
        self.name = name
        self.species = species


class Filipino(Nationality):
    pass


class Indonesian(Nationality):
    pass


class Spaniard(Nationality):
    pass


class Stitch(Alien):
    pass


class Avengers(Alien):
    pass

filipino = Filipino("PSHS_Galaxy", "Earth", "Filipino", "Asia")
indonesian = Indonesian("PSHS_Galaxy", "Earth", "Indonesian", "Asia")
spaniard = Spaniard("PSHS_Galaxy", "Earth", "Spaniard", "Europe")

stitch = Stitch("PSHS_Galaxy", "Earth", "Stitch", "Experiment 626")
avengers = Avengers("PSHS_Galaxy", "Earth", "Avengers", "Superheroes")


print("NATIONALITY")

for person in [filipino, indonesian, spaniard]:
    print(person.nationality)
    print("Galaxy:", person.galaxy)
    print("Planet:", person.get_planet())
    print("Continent:", person.continent)
    print()


print("ALIEN")

for alien in [stitch, avengers]:
    print(alien.name)
    print("Galaxy:", alien.galaxy)
    print("Planet:", alien.get_planet())
    print("Species:", alien.species)
    print()


