# Reflection

Question: How does using @property make your code easier to read compared to using traditional get_ and set_ methods?

Answer: When I ran my code, rectangle.width was easy to read and use. It works like a normal variable, so I don't need to write get_ or set_. The setter also stops wrong values, like a negative height. This shows that @property makes my code shorter and easier to understand