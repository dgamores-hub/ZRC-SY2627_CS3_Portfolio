class BankAccount:
    def __init__(self, account_number, balance):
        self.__account_number = ""
        self.__balance = 0
        self.set_account_number(account_number)
        self.set_balance(balance)

    def set_account_number(self, account_number):
        self.__account_number = account_number

    def set_balance(self, balance):
        if balance >= 0:
            self.__balance = balance
        else:
            print("The balance must be not be a negative number.")

    @property
    def account_number(self):
        return self.__account_number

    @property
    def balance(self):
        return self.__balance


account1 = BankAccount("", 0)
account1.set_account_number(12345)
account1.set_balance(1000)

print("Account 1")
print("Account Number:", account1.account_number)
print(f"Balance: {account1.balance:.2f}")

print()
print("Update balance to -100")
account1.set_balance(-100)
print("Account Number:", account1.account_number)
print(f"Balance: {account1.balance:.2f}")