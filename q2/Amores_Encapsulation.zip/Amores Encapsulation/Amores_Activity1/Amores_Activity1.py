class GameCharacter:
    def __init__(self, username):
        self.username = username


class BankAccount:
    def __init__(self, balance):
        self.__balance = balance


class Vehicle:
    def __init__(self, engineCode):
        self._engineCode = engineCode


class Student:
    def __init__(self, schoolName):
        self.schoolName = schoolName


class VotingSystem:
    def __init__(self, voterID):
        self.__voterID = voterID


hero = GameCharacter("DragonSlayer01")
print(hero.username)

car = Vehicle("ENG-2026")
print(car._engineCode)

account = BankAccount(5000)
try:
    print(account.__balance)
except AttributeError:
    print("Cannot access balance: it is private.")